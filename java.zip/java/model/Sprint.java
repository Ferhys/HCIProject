package model;

import java.util.ArrayList;
import java.util.Date;

public class Sprint {

	public String name;
	public String description;
	public int status;
	public Date startDate;
	public Date endDate;
	private ArrayList<Story> storyList;
	
	public Sprint() {
		storyList = new ArrayList<>();
		
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getStatus() {
		return status;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}
	
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void addStory(Story story) {
		storyList.add(story);
	}
	
	public void deleteStory(Story story) {
		storyList.remove(story);
	}
	
	public Story getStory(int i) {
		return storyList.get(i);
	}
	
}
